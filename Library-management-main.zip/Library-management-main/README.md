# Library-management
This is a local server project to run this we have to change path in python files with our local paths in our system
